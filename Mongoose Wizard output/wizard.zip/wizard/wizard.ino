#include "WiFi.h"
#include "src/mongoose_glue.h"

#define LED_PIN LED_BUILTIN  // LED pin
#define WIFI_SSID "wifi_network_name"  // Change this
#define WIFI_PASS "wifi_password"      // And this

void setup() {
  Serial.begin(115200);
  while (!Serial) delay(50);

  pinMode(LED_PIN, OUTPUT);

  // Set logging function to serial print
  mg_log_set_fn([](char ch, void *) { Serial.print(ch); }, NULL);
  mg_log_set(MG_LL_DEBUG);

  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASS);
  while(WiFi.status() != WL_CONNECTED) delay(100);
  MG_INFO(("Connected; IP: %s", WiFi.localIP()));

  mongoose_init();
}

void loop() {
  mongoose_poll();
}

extern "C" int lwip_hook_ip6_input(struct pbuf *p, struct netif *inp) __attribute__((weak));
extern "C" int lwip_hook_ip6_input(struct pbuf *p, struct netif *inp) {
  if (ip6_addr_isany_val(inp->ip6_addr[0].u_addr.ip6)) {
    pbuf_free(p);
    return 1;
  }
  return 0;
}
